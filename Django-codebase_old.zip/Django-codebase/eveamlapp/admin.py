from django.contrib import admin

# Register your models here.


def get():
    return "Admin"
