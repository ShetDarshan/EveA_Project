const config = {
    apiKey: "AIzaSyD4svmLSEA5IDa49VKgK45vbUCL7JkO52I",
    authDomain: "evea-prj.firebaseapp.com",
    databaseURL: "https://evea-prj.firebaseio.com",
    projectId: "evea-prj",
    storageBucket: "evea-prj.appspot.com",
    messagingSenderId: "342374627785",
    appId: "1:342374627785:web:3242138c0109915fc19018",
    measurementId: "G-4L5XLJ17HJ"
  };