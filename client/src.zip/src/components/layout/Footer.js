import React, { Component } from 'react'
import "../../css/bootstrap.min.css"
import "../../css/App.css"

 class Footer extends Component {
  render() {
    return (
        <footer className="text-white  p-4 text-center footer-custom ">
        Copyright EVEA &copy; 2019 TUD
      </footer>
    )
  }
}
export default Footer;