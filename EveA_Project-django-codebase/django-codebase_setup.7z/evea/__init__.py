import firebase_admin
from firebase_admin import credentials

cred = credentials.Certificate("/c/Users/Aniruddha/OneDrive/Project/Django_EVEA/evea-prj-firebase-adminsdk-xgpyn-eba7f5230f.json")
firebase_admin.initialize_app(cred)