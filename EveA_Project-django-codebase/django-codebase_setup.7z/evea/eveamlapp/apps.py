from django.apps import AppConfig


class EveamlappConfig(AppConfig):
    name = 'eveamlapp'

