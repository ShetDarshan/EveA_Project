import sys

import json
from datetime import datetime
from google.cloud import firestore


class DataProcess:

    @staticmethod
    def saveeventdata(eventData):
        db = firestore.Client();
        eventData:list
        ##response = requests.post('http://www.example.com/rest-auth/users/1/',data=eventData)
        i=0
        for event in eventData:
            i=i+1
            print(event.id)
            data = {
                u'title': u''+event.title,
                u'time': u''+event.time,
                u'location': u''+event.location,
                u'summary': u''+event.summary,
                u'img':u''+event.img
            }
            db.collection(u'events').document(u''+event.id).set(data)

        print(i)
        return eventData;

    @staticmethod
    def geturls():
        urls = list();

        url = "https://dublin.ie/whats-on";
        urls.append(url)
        print(urls, sys.stderr)
        return urls