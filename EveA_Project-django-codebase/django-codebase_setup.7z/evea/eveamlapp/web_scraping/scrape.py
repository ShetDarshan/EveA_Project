from plistlib import Data
from urllib.request import urlopen as uReq
from bs4 import BeautifulSoup as soup
import uuid

from .models import EventData
from .service import DataProcess
from datetime import datetime
import sys


class WebScrape:

    @staticmethod
    def scrapeweb():

        data_list = []

        urls = DataProcess.geturls();

        for url in urls:
            uClient =uReq(url)
            page_html = uClient.read()
            uClient.close()

            page_soup = soup(page_html, "html.parser")

            # Finding each events
            article = page_soup.find_all('article', class_="event card")

            print(len(article))

            for container in article:
                # container = article[0]
                title = container.h2.text
                time = container.time.text
                p_tags = container.findAll('p')
                location = p_tags[0].text
                summary = p_tags[1].text.strip()
                img = container.div["style"]

                data = EventData();

                data.id = uuid.uuid1().__str__()
                data.title = title
                data.time = time
                data.location = location
                data.summary = summary
                data.img = img

                data_list.append(data)

        return data_list
